# ChipQC Guardian: Human-reviewed quality control for OoC brightfield images

> **Publication status:** Draft. Replace the marked links and result fields only with verified public artifacts. Do not post as a completed submission until the required registration and final Kaggle Writeup have been confirmed. This manuscript does not claim a competition entry or score.

**Submission category: End-to-End System**

## Demo video

`[PUBLIC VIDEO URL — REQUIRED; verify playback without login, ≤5 minutes]`

## Public code repository

`[PUBLIC REPOSITORY URL — REQUIRED; verify fresh-install reproduction]`

## Project summary (approximately 230 words)

Organ-on-a-chip (OoC) experiments generate brightfield images that researchers inspect to judge whether a culture is suitable for further analysis. ChipQC Guardian explores a more transparent quality-control workflow: it presents the original image, an interpretable quality estimate, and an explicit suggestion to PASS, REVIEW, or REACQUIRE. Researchers remain responsible for the final choice. The source's expert `good`/`bad` labels describe sample quality; a poor sample is not automatically fixed by taking another photograph, so a re-acquisition suggestion requires separate evidence of an unusable image or a human decision.

We use the public OoC image dataset of Movčana and colleagues. Its spreadsheet contains 3,072 unique image IDs across six cell lines. Numeric labels map to `good` and `bad` in official archive-preview examples; the complete image-to-label join is a release gate. Rather than randomly dividing images, we group all images sharing one of 59 six-digit date-like filename prefixes into the same partition. This guards against related acquisitions appearing on both sides of a test split.

The stronger model uses public ImageNet MobileNetV2 embeddings, an ExtraTrees classifier selected only on calibration groups, and logistic probability calibration. On 670 images from 12 held-out prefix groups, it achieved 0.718 accuracy, 0.712 balanced accuracy, 0.712 macro-F1, 0.772 AUROC, and 0.204 Brier score. Group-bootstrap intervals are wide, and no calibration threshold met our planned ≤10% accepted-error objective with at least 20 accepted images. We therefore show the research score but do not claim a safe automated PASS policy.

## Problem and application value

Routine brightfield inspection is a bottleneck when many OoC samples and time points are imaged. A binary model output alone is hard to act on: the cost of mistakenly accepting a poor-quality sample differs from the cost of asking a researcher to review an uncertain image. ChipQC Guardian separates the model's estimate from an operational decision and shows the reason for each suggestion. Its intended value is to prioritize human attention and make acceptance rules auditable. Time saved, error reduction, and generalization to another laboratory remain hypotheses until measured prospectively.

## Data and safeguards

The [OoC dataset](https://doi.org/10.5281/zenodo.10203721) contains brightfield images from six cell lines, described in the [dataset paper](https://doi.org/10.3390/data9020028). The local spreadsheet audit found 3,072 records, 59 acquisition-date-like prefixes, and missing values in seeding density (344), elapsed hours (2,244), and flow rate (859). `1 = good` and `2 = bad` are supported by two image-ID matches to the official `good`/`bad` folder preview; a full join is still required. Raw image rights are separate from this repository's code license.

All images with the same prefix remain in one of train, validation, or test. We inspect class and cell-line balance, exact/near duplicates, and missingness patterns. The prefix is a conservative proxy, not a confirmed chip or donor ID. This makes our planned held-out evaluation more meaningful than a random image split, but it does not prove external generalization.

## Method and interface

The reproducible baseline extracts pixel descriptors for brightness, contrast, entropy, gradients, edges, and focus-related structure. The selected model instead uses a frozen 1,280-dimensional MobileNetV2 representation and an ExtraTrees classifier; three capacity settings were compared on calibration groups only. Logistic calibration and a 0.62 classification threshold were fitted on those groups before one test evaluation. The interface labels acquisition-rule PASS/REVIEW/REACQUIRE outputs as unvalidated previews and shows the research classifier separately. It keeps the original image visible and exports a manifest. No output is a clinical, drug-response, or tissue-viability claim.

## Results and validation

The official 6.7 GB archive matched MD5 `8f7e058996203d48eb03b2d86c0a2e4d`; all 3,072 rows matched and decoded without label-path conflict. The frozen split contains 35/12/12 train/calibration/test groups and 1,804/598/670 images. On test, the selected model achieved **0.718 accuracy, 0.712 balanced accuracy, 0.712 macro-F1, 0.772 AUROC, and 0.204 Brier score**. Its confusion matrix (rows actual bad/good) was `[[193,120],[69,288]]`. Complete-group bootstrap 95% intervals were 0.510–0.815 for balanced accuracy and 0.552–0.875 for AUROC, showing substantial uncertainty. A549 test balanced accuracy was 0.551 versus 0.848 for CACO; HSAEC and NHBE slices are too sparse for stable conclusions. The handwritten-feature baseline reached only 0.508 balanced accuracy and 0.536 AUROC. The paper's approximately **0.81 accuracy** uses a different protocol and is not our score.

No calibration threshold accepted at least 20 images with ≤10% observed error. Accordingly, the current prototype does not automate PASS: the final operational action remains a human decision. This negative result is part of the evidence, not hidden by the interface.

## Reproduce and inspect

Install `requirements.txt` and `requirements-vision.txt`, obtain the source files from Zenodo, and run `audit_metadata.py`, `prepare_dataset.py`, `train_baseline.py`, `extract_embeddings.py`, `train_vision_model.py`, and `evaluate.py`. Start the interface with `streamlit run app.py`. The public repository must include exact arguments, dependency versions, split manifest, weight acquisition instructions, and output hashes. The [technical report](technical_report.md), [data card](../DATA_CARD.md), [model card](../MODEL_CARD.md), and [experiment protocol](experiment_protocol.md) explain limits and measurements.

## Links and references

- Interactive demo: `[OPTIONAL PUBLIC URL; remove if unavailable]`
- Dataset: [Movčana et al., Zenodo 10.5281/zenodo.10203721](https://doi.org/10.5281/zenodo.10203721)
- Dataset paper: [Movčana et al., *Data* 9(2), 28 (2024)](https://doi.org/10.3390/data9020028)
- Challenge: [AI4S Open Innovation: AI for Life Science](https://www.kaggle.com/competitions/ai-4-s-open-innovation-artificial-intelligence-for-life-scien/overview/description)
